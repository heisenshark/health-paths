
    window.reactComponents = {};

    window.vueComponents = {};

  
      import React from "react";

      import ReactDOM from "react-dom";


      import ReactWrapper from '../node_modules/better-docs/lib/react-wrapper.js';

      window.React = React;

      window.ReactDOM = ReactDOM;

      window.ReactWrapper = ReactWrapper;

    
    import './styles/reset.css';

    import './styles/iframe.css';

  import Component0 from '../src/components/AddPointModal.tsx';
reactComponents['AddPointModal'] = Component0;

import Component1 from '../src/screens/StopPointEditScreen.tsx';
reactComponents['AudioPickPlay'] = Component1;

import Component2 from '../src/screens/AudioRecordingScreen.tsx';
reactComponents['AudioRecordingScreen'] = Component2;

import Component3 from '../src/screens/AudioRecordingScreen.tsx';
reactComponents['recordingGui'] = Component3;

import Component4 from '../src/components/BottomBar.tsx';
reactComponents['BottomBar'] = Component4;

import Component5 from '../src/components/EditWaypointModal.tsx';
reactComponents['EditWaypointModal'] = Component5;

import Component6 from '../src/components/HeaderBar.tsx';
reactComponents['HeaderBar'] = Component6;

import Component7 from '../src/screens/HelpScreen.tsx';
reactComponents['HelpScreen'] = Component7;

import Component8 from '../src/screens/HomeScreen.tsx';
reactComponents['HomeScreen'] = Component8;

import Component9 from '../src/components/MapCard.tsx';
reactComponents['MapCard'] = Component9;

import Component10 from '../src/screens/MapEditScreen.tsx';
reactComponents['MapEditScreen'] = Component10;

import Component11 from '../src/screens/MapExplorerScreen.tsx';
reactComponents['MapExplorerScreen'] = Component11;

import Component12 from '../src/components/MapGUIButton.tsx';
reactComponents['MapGUIButton'] = Component12;

import Component13 from '../src/components/MapInfoModal.tsx';
reactComponents['MapInfoModal'] = Component13;

import Component14 from '../src/screens/MapViewScreen.tsx';
reactComponents['MapViewScreen'] = Component14;

import Component15 from '../src/screens/MapWebExplorerScreen.tsx';
reactComponents['MapWebExplorerScreen'] = Component15;

import Component16 from '../src/screens/MapWebPreviewScreen.tsx';
reactComponents['MapWebPreview'] = Component16;

import Component17 from '../src/components/Markers.tsx';
reactComponents['Markers'] = Component17;

import Component18 from '../src/components/ModalChoice.tsx';
reactComponents['ModalChoice'] = Component18;

import Component19 from '../src/components/ZoomGUI.tsx';
reactComponents['exports'] = Component19;

import Component20 from '../app.tsx';
reactComponents['exports'] = Component20;

import Component21 from '../src/components/OptionsModal.tsx';
reactComponents['OptionsModal'] = Component21;

import Component22 from '../src/screens/OptionsScreen.tsx';
reactComponents['OptionsScreen'] = Component22;

import Component23 from '../src/screens/OtherSettingsScreen.tsx';
reactComponents['OtherSettingsScreen'] = Component23;

import Component24 from '../src/components/Rating.tsx';
reactComponents['Rating'] = Component24;

import Component25 from '../src/components/SquareButton.tsx';
reactComponents['SquareButton'] = Component25;

import Component26 from '../src/screens/StopPointEditScreen.tsx';
reactComponents['StopPointEditScreen'] = Component26;

import Component27 from '../src/components/StopPoints.tsx';
reactComponents['StopPoints'] = Component27;

import Component28 from '../src/components/TileButton.tsx';
reactComponents['TileButton'] = Component28;

import Component29 from '../src/components/TipDisplay.tsx';
reactComponents['TipDisplay'] = Component29;

import Component30 from '../src/components/TrackLine.tsx';
reactComponents['TrackLine'] = Component30;